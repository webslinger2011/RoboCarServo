
This program shows how to wirelessly control two servos and geared motors using
the arduino nano and the nrf24L01 module.

We'll be using two joysticks to control the servos and motors. 




